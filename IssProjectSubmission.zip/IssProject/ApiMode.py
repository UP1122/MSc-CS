class ApiSetting:
    """This class contains the settings that determine which configuration the project runs in"""
    distrubuted = False
    runningServerOnly = False
