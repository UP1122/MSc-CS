stock3psi ={'cd': {'Price': '1', 'Quantity': '165', 'Delivery': 'No'},
            'ccwds': {'Price': '15', 'Quantity': '55', 'Delivery': '1'}}