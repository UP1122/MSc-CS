CREATE TABLE Inventory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ProductName VARCHAR(30) NOT NULL,
    Description TEXT NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    Quantity INT,
    create_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO Inventory (id, ProductName, Description, Price, Quantity)
VALUES ('1', 'HP laptop' , 'HP Pavilion 15', '1000', '10');
INSERT INTO Inventory (id, ProductName, Description, Price, Quantity)
VALUES ('2', 'OnePlus Phone' , 'OnePlus 9', '500', '20');
INSERT INTO Inventory (id, ProductName, Description, Price, Quantity)
VALUES ('3', 'Polo Shirt' ,'Black Polo Shirt Large', '100', '25');
INSERT INTO Inventory (id, ProductName, Description, Price, Quantity)
VALUES ('4', 'Seiko Watch' ,'Mens Seiko Chronometer', '699', '14');

SELECT * FROM Inventory