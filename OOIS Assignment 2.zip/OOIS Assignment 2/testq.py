import sqlite3

con = sqlite3.connect("C:/Users/upara/Desktop/Python online shopping OOIS/stockinventory.sql")
mycur = con.cursor()
mycur.execute("SELECT * FROM Inventory;")
available_table=(mycur.fetchall())

print(available_table)